# faith-in-a-firestorm-sanitized-corrupt-scrivx-negative-fixture

Negative derivative fixture for bounded Phase 0 Scrivener evidence work.

## Lineage

raw source project -> sanitized derivative -> intentionally corrupted sanitized copy

## Purpose

This packet is for fail-closed negative evidence only. The authoritative `*.scrivx` in the sanitized copy was intentionally malformed while preserving the surrounding package shape.

## What changed

- the sanitized derivative was copied
- the copied `*.scrivx` was intentionally made malformed
- the rest of the package shape was left intact

## Restrictions

Evidence only. Not proof of general Scrivener support.
